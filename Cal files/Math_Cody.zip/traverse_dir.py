import os
import pdb
import scipy as sp
import scipy.io as spio
import numpy as np
from matplotlib import pyplot as plt


def list_files(dir):
	r = []
	for root,dir,files in os.walk(dir):
		for name in files:
			if name == 'cal.mat':
				r.append(os.path.join(root, name))
			else:
				os.remove(os.path.join(root, name))
	return r
#Set This to your respective Math Cody folder
x = list_files('C:\\Users\\Cody Hutchins\\Desktop\\Math_Cody')
matplots = []
for i in x:
	matplots.append(spio.loadmat(i))
for j in matplots:
 	plt.plot(j['LO_f'][0],np.linspace(0,1,216))
 	plt.show()
#pdb.set_trace()
print(x)
