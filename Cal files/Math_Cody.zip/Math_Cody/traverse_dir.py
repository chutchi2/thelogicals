import os
import pdb
import scipy as sp
import scipy.io as spio
import numpy as np
from matplotlib import pyplot as plt


def list_files(dir):
	r = []
	for root,dir,files in os.walk(dir):
		for name in files:
			if name == 'cal.mat':
				r.append(os.path.join(root, name))
			else:
				os.remove(os.path.join(root, name))
	return r
#Set This to your respective Math Cody folder
x = list_files('C:\\Users\\Cody Hutchins\\Desktop\\Classes\\ECE 4899\\git_thelogicals\\Cal files\\Math_Cody')
matplots = []

mymat = []
for i in x:
	matplots.append(spio.loadmat(i))

for jj in range(0,10):
	for kk in matplots:
		mymat = []
		for i in range(0,216):
			mymat.append(kk['gain_db'][i][jj])
		plt.plot(kk['LO_f'][0],mymat)
	plt.show()	
print(x)
